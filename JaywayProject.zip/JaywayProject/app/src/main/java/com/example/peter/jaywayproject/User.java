package com.example.peter.jaywayproject;

public class User { //User class should be named Customer my bad :(

    private String firstName;
    private String lastName;

    public User() {
        this.firstName = "?";
        this.lastName = "?";
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "User{" +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }
}
