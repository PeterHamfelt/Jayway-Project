package com.example.peter.jaywayproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

import ai.api.AIListener;
import ai.api.android.AIConfiguration;
import ai.api.android.AIService;
import ai.api.model.AIError;
import ai.api.model.AIResponse;
import ai.api.model.Result;

public class MainActivity extends AppCompatActivity implements AIListener, View.OnClickListener, TextToSpeech.OnInitListener {


    private AIService aiService;
    private Button listenButton;
    private TextView resultTextView;
    private User user = new User();
    private Staff staff = new Staff();
    private DatabaseReference myRef;


    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.6F);


    Voice voice;
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tts = new TextToSpeech(this, this);

        int permission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        if(permission != PackageManager.PERMISSION_GRANTED)
        {
            makeRequest();
        }

        listenButton = (Button) findViewById(R.id.listenButton);
        resultTextView = (TextView) findViewById(R.id.resultTextView);


        //Dialogflow SDK
        final AIConfiguration config = new AIConfiguration("4bcbb0f52bf740068b9d25f2fe4f2316",
                AIConfiguration.SupportedLanguages.English,
                AIConfiguration.RecognitionEngine.System);
        aiService = AIService.getService(this, config);
        aiService.setListener(this);




    }


    //Write to database //customer
    protected void addUserToDatabase()
    {
        String totalString = user.getFirstName() + user.getLastName();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("CustomerUsers").child(totalString);

        myRef.child("FirstName").setValue(user.getFirstName());
        myRef.child("SecondName").setValue(user.getLastName());

    }

    protected void addStaffToDatabase()
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("StaffUsers").child(staff.getFirstName()+staff.getLastName());

        myRef.child("FirstName").setValue(staff.getFirstName());
        myRef.child("SecondName").setValue(staff.getLastName());
        myRef.child("Status").setValue(staff.getStatus());
        myRef.child("Office").setValue(staff.getOfficeLocation());
    }


    //read / remove from database
    protected void removeFromDatabase ()
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("StaffUsers").child(staff.getFirstName()+staff.getLastName());
        myRef.removeValue();
        if(myRef.removeValue() != null)
        {
            resultTextView.setText("succes! removed!");
        }
        else
        {
            resultTextView.setText("not removed!");
        }
    }

    protected void searchForStaff()
    {
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("StaffUsers").child(staff.getFirstName() + staff.getLastName());

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String test = dataSnapshot.child("Office").getValue().toString();
                String status = dataSnapshot.child("Status").getValue().toString();
                if(status.equals("Available"))
                {
                    say("Excellent! You will find " + staff.getFirstName() + " " + staff.getLastName() + " at office " + test + " right now!");
                    resultTextView.setText("Excellent! You will find " + staff.getFirstName() + " " + staff.getLastName() + " at office " + test + " right now!");
                }
                else if(status.equals("Away"))
                {
                    say(staff.getFirstName() + staff.getLastName() + " is unfortunately not by their office " + test + " at the moment!");
                    resultTextView.setText(staff.getFirstName() + staff.getLastName() + " is unfortunately not by their office " + test + " at the moment!");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { }
        });


    }

    protected void updateStaffStatusAway()
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("StaffUsers").child(staff.getFirstName() + staff.getLastName());
        myRef.child("Status").setValue("Away");

    }

    protected void updateStaffStatusAvailable()
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("StaffUsers").child(staff.getFirstName() + staff.getLastName());
        myRef.child("Status").setValue("Available");



        //get office location
        //get status
    }

    //Permission
    protected void makeRequest()
    {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 101);
    }

    public void listenButtonOnClick(final View view) {

        //When button clicked customer can input voice message
        aiService.startListening();
        listenButton.startAnimation(buttonClick);
    }


    //Buttons and widgets
    @Override
    public void onResult(AIResponse result) {

        // Get reslut parameters from Dialog
        Result result1 = result.getResult();

        // Show dialogflow results in TextView.
        resultTextView.setText(result.getResult().getFulfillment().getSpeech());


        //Save and use data input
        //getAction() data comes from intent in dialogflow (Action and parameters section)
        String entityUser;
        String entityStaff;
        String str = result1.getAction();
        switch (str)
        {
                //Customer
            case "RegisterCustomer.getFirstName":
                entityUser = result1.getStringParameter("given-name");
                user.setFirstName(entityUser);
                break;
            case "RegisterCustomer.getLastName":
                entityUser = result1.getStringParameter("last-name");
                user.setLastName(entityUser);   //result1.getResolvedQuery()
                break;
            case "RegisterCustomer.confirmYes":
                addUserToDatabase();
                break;
                //Staff
            case "SearchForStaff.getFirstName":
                entityStaff = result1.getStringParameter("given-name");
                staff.setFirstName(entityStaff);
                entityStaff = result1.getStringParameter("last-name");
                staff.setLastName(entityStaff);
                break;
            case "SearchForStaff.confirmYes":
                searchForStaff();
                //speak if not found
                break;
            case "RegisterStaff.getFullName":
                entityStaff = result1.getStringParameter("given-name");
                staff.setFirstName(entityStaff);
                entityStaff = result1.getStringParameter("last-name");
                staff.setLastName(entityStaff);
                break;
            case "RegisterStaff.getOffice":
                entityStaff = result1.getStringParameter("any");
                staff.setOfficeLocation(entityStaff);
                break;

            case "RegsiterStaff.confirmYes":
                addStaffToDatabase();
                break;
            case "StaffStatusUpdate.getName":
                entityStaff = result1.getStringParameter("given-name");
                staff.setFirstName(entityStaff);
                entityStaff = result1.getStringParameter("last-name");
                staff.setLastName(entityStaff);
                break;
            case "StaffStatusUpdate.available":
                entityStaff = result1.getStringParameter("StatusAvailable");
                staff.setStatus(entityStaff);
                //update office status AVAILABLE in database
                updateStaffStatusAvailable();
                break;
            case "StaffStatusUpdate.away":
                entityStaff = result1.getStringParameter("StatusAway");
                staff.setStatus(entityStaff);
                resultTextView.setText(entityStaff);
                //update office status AWAY in database
                updateStaffStatusAway();
                break;
            case "RemoveStaff.getNameToRemove":
                entityStaff = result1.getStringParameter("given-name");
                staff.setFirstName(entityStaff);
                entityStaff = result1.getStringParameter("last-name");
                staff.setLastName(entityStaff);
                removeFromDatabase();
                break;

        }

        //Output voice
        say(result.getResult().getFulfillment().getSpeech());
    }

    @Override
    public void onError(AIError error) {
        resultTextView.setText(error.toString());
    }

    @Override
    public void onAudioLevel(float level) {

    }

    @Override
    public void onListeningStarted() {

    }

    @Override
    public void onListeningCanceled() {

    }

    @Override
    public void onListeningFinished() {

    }

    @Override
    public void onClick(View v) {

    }

    //Voice (text to speech)
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
        }
    }

    public void say(String announcement) {
        tts.speak(announcement, TextToSpeech.QUEUE_FLUSH, null, null);
    }
}






